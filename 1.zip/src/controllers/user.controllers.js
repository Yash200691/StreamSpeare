import {asyncHandler} from '../utils/asyncHandler.js'
import {ApiError} from '../utils/apiError.js'
import {User} from '../models/user.model.js'
import { uploadCloudinary } from '../utils/cloudinary.js'
import {ApiResponse} from '../utils/apiResponse.js'
import jwt from 'jsonwebtoken'

const generateAccessAndRefreshTokens = async(userId)=>{
    try {
        const user=await User.findById(userId)
        const accessToken= user.generateAccessToken()
        const refreshToken=user.generateRefreshToken()

        user.refreshToken = refreshToken;
        await user.save({validateBeforeSave: false});

        return {accessToken,refreshToken}

    } catch (error) {
        throw new ApiError(500, 'Error generating tokens');
    }
}


 const registerUser = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Validate required fields
    if (!username || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Safely handle file uploads
    const avatarPath = req.files?.avatar?.[0]?.path || null;
    const coverImagePath = req.files?.coverImage?.[0]?.path || null;

    // Example: If using Cloudinary upload
    let avatarUrl = null;
    let coverImageUrl = null;

    if (avatarPath) {
      const avatarUpload = await uploadCloudinary(avatarPath, {
        folder: "avatars",
      });
      avatarUrl = avatarUpload.secure_url;
    }

    if (coverImagePath) {
      const coverImageUpload = await cloudinary.uploader.upload(coverImagePath, {
        folder: "coverImages",
      });
      coverImageUrl = coverImageUpload.secure_url;
    }

    // Create new user
    const newUser = await User.create({
      username,
      email,
      password,
      avatar: avatarUrl,
      coverImage: coverImageUrl,
    });

   res.redirect('/login')

  } catch (error) {
    console.error("Error in registerUser:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

const loginUser=asyncHandler(async(req,res)=>{
        //req.body=> Data
        //check for email or username
        //check password
        //if user exists, generate access token and refresh token

        const {email,username,password}=req.body
        if(!(username||password)){
            throw new ApiError(400,'username or email required')
        }

        const user=await User.findOne({
            $or:[{username},{email}]
        })
        if(!user){
            throw new ApiError(404,'User not found')
        }

        const isPasswordCorrect=await user.isPasswordCorrect(password)
        if(!isPasswordCorrect){
            throw new ApiError(401,'Invalid password')
        }

        const {accessToken,refreshToken}=await generateAccessAndRefreshTokens(user._id)

        const loggedInUser=await User.findById(user._id).select('-password -refreshToken')

        const options={
            httpOnly:true,
            secure:true
       }

    //    return res.
    //    status(200).
    //    cookie('refreshToken',refreshToken,options).
    //    cookie('accessToken',accessToken,options).
    //    json(
    //     new ApiResponse(200,{
    //         user:loggedInUser,
    //         accessToken,
    //         refreshToken
    //     },
    //     "User logged in successfully"
    // )
    //    )

       return res.redirect('/home')

    })

    const logoutUser=asyncHandler(async(req,res)=>{
        await User.findByIdAndUpdate(req.user._id,{
            $unset:{
                refreshToken:1
            }
        })
         const options={
            httpOnly:true,
            secure:true
       }
      
    return res.status(200)
    .clearCookie('refreshToken',options)
    .clearCookie('accessToken',options)
    .json(new ApiResponse(200, null, 'User logged out successfully')); 
    })

    const refreshAccessToken=asyncHandler(async(req,res)=>{
        const incomingRefreshToken=req.cookies.refreshToken;

        if(!incomingRefreshToken){
            throw new ApiError(401,'Refresh token is required')
        }
        const decodedToken=jwt.verify(incomingRefreshToken, process.env.REFRESH_TOKEN_SECRET)

      const user= await User.findById(decodedToken._id)
      if(!user){
        throw new ApiError(404,'Invalid Refresh Token')
      }

      if(user.refreshToken!==incomingRefreshToken){
        throw new ApiError(401,'Refresh token is used or expired')
      }

      const {accessToken,newRefreshToken}=await generateAccessAndRefreshTokens(user._id)

      const options={
        httpOnly:true,
        secure:true
      }
      return res
      .status(200)
      .cookie('refreshToken',newRefreshToken,options)
      .cookie('accessToken',accessToken,options)
      .json(
         new ApiResponse(
            200,
            {accessToken,newRefreshToken},
            'Access token refreshed successfully'
        )
      )
        
    })

    const changeCurrentPassword=asyncHandler(async(req,res)=>{
        const {oldPassword,newPassword}=req.body
        if(!oldPassword || !newPassword){
            throw new ApiError(400,'Old and new passwords are required')
        }
        if(oldPassword===newPassword){
            throw new ApiError(400,'Old and new passwords cannot be the same')
        }
        const user=await User.findById(req.user._id)
        if(!user){
            throw new ApiError(404,'User not found')
        }
        const isPasswordCorrect=await user.isPasswordCorrect(oldPassword)
        if(!isPasswordCorrect){
            throw new ApiError(401,'Old password is incorrect')
        }
        user.password=newPassword
        await user.save({validateBeforeSave: false})

        return res
        .status(200)
        .json(
            new ApiResponse(200, null, 'Password changed successfully')
        )
    })
     
    const getCurrentUser=asyncHandler(async(req,res)=>{
        const user=await User.findById(req.user._id).select('-password -refreshToken')
        if(!user){
            throw new ApiError(404,'User not found')
        }

        return res
        .status(200)
        .json(
            new ApiResponse(
                200,user,
                'Current user fetched successfully'
            )
        )
    })

    const updateAccountDetails=asyncHandler(async(req,res)=>{
        const {fullName,email}=req.body
        if(!fullName&&!email){
            throw new ApiError(400,'there is nothing to update')
        }
       const user= await User.findByIdAndUpdate(req.user._id,
            {
                $set:{
                    fullName,
                    email
                }
            },
            {new:true}
        ).select('-password')

        return res
        .status(200)
        .json(
            new ApiResponse(200,user,"Account details updated successfully")
        )

    })

    const updateUserAvatar=asyncHandler(async(req,res)=>{
        const avatarLocalPath=req.file?.path
        if(!avatarLocalPath){
            throw new ApiError(400,"Avatar Image file is missing")
        }
        const avatar=await uploadCloudinary(avatarLocalPath)
        if(!avatar.url){
            throw new ApiError(400,'avatar Image url not found')
        }
        const user=await User.findByIdAndUpdate(req.user?._id,{
            $set:{
                avatar:avatar.url
            }
        },{new:true}).select('-password')

        if(!user){
            throw new ApiError(404,"user not found")
        }

        return res
        .status(200)
        .json(
            new ApiResponse(200,user,"Avatar Image changed successfully")
        )
    })
     const updateUserCoverImage=asyncHandler(async(req,res)=>{
        const coverImageLocalPath=req.file?.path
        if(!coverImageLocalPath){
            throw new ApiError(400,"CoverImage file is missing")
        }
        const coverImage=await uploadCloudinary(coverImageLocalPath)
        if(!coverImage.url){
            throw new ApiError(400,'CoverImage url not found')
        }
        const user=await User.findByIdAndUpdate(req.user?._id,{
            $set:{
                coverImage:coverImage.url
            }
        },{new:true}).select('-password')

        if(!user){
            throw new ApiError(404,"user not found")
        }

        return res
        .status(200)
        .json(
            new ApiResponse(200,user,"CoverImage changed successfully")
        )
    })

    const getUserChannelProfile=asyncHandler(async(req,res)=>{
        const {username}=req.params
        if(!username?.trim){
            throw new ApiError(400,"username is missing")
        }
        const channel=await User.aggregate([
            {
                $match:{
                    username:username?.toLowerCase
                }
            },
            {
                $lookup:{
                    from:"subscriptions",
                    localfield:"_id",
                    foreignField:"channel",
                    as:"subscribers"
                }
            },
            {
                $lookup:{
                    from:"subscriptions",
                    localfield:"_id",
                    foreignField:"subscriber",
                    as:"subscribedTo"
                }
            },
            {
                $addFields:{
                    subscribersCount:{
                        $size:"$subscribers"
                    },
                    channelsSubscribedToCount:{
                        $size:"$subscribedTo"
                    },
                    isSubscribed:{
                        $cond:{
                            if:{$in:[req.user?._id,"$subscribers.subscribe"]},
                            then:true,
                            else:false  
                        }
                    }
                },  
            },
            {
                $project:{
                    fullName:1,
                    userName:1,
                    subscribersCount:1,
                    channelsSubscribedToCount:1,
                    isSubscribed:1,
                    avatar:1,
                    coverImage:1
                }
            }
        ])
        if(!channel?.length){
            throw new ApiError(404,"channel does not exist")
        }

        return res
        .status(200)
        .json(
            new ApiResponse(200,channel[0],"channel fetched successfully")
        )
    })

    const getWatchHistory=asyncHandler(async(req,res)=>{
        const user=await User.aggregate([
            {
                $match:{
                    _id:new mongoose.Types.ObjectId(req.user._id)
                }
            },
            {
                $lookup:{
                    from:"videos",
                    localField:"watchHistory",
                    foreignField:"_id",
                    as:"watchHistory",
                    pipeline:[
                        {
                            $lookup:{
                                from:"users",
                                localField:"owner",
                                foreignField:"_id",
                                as:"owner",
                                pipeline:[
                                    {
                                        $project:{
                                            fullName:1,
                                            username:1,
                                            avatar:1
                                        }
                                    },
                                    {
                                        $addFields:{
                                            owner:{
                                                $first:"$owner"
                                            }
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                }
            }
        ]
      )
      return res
      .status(200)
      .json(
        new ApiResponse(200,
            user[0].watchHistory,
            "watch history fetched"
        )
      )
    })
export {
    registerUser,
    loginUser,
    logoutUser,
    refreshAccessToken,
    changeCurrentPassword,
    getCurrentUser,
    updateAccountDetails,
    updateUserAvatar,
    updateUserCoverImage,
    getWatchHistory,
    getUserChannelProfile
}