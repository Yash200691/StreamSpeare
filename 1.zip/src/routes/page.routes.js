import { Router } from 'express'

const router = Router()

// Home (video grid)
router.get(['/', '/home'], async (req, res) => {
  // Initial page render – the grid JS will fetch /api/v1/videos
  res.render('home', { title: 'Home', user: req.user || null })
})

// Watch page (/:id)
router.get('/watch/:id', async (req, res) => {
  const { id } = req.params
  // Client-side script will fetch video details & comments
  res.render('watch', { title: 'Watch', videoId: id, user: req.user || null })
})

// Upload page (auth required visually; API already checks)
router.get('/upload', (req, res) => {
  res.render('upload', { title: 'Upload', user: req.user || null })
})

// Auth
router.get('/login', (req, res) => res.render('auth/login', { title: 'Login' }))
router.get('/signup', (req, res) => res.render('auth/signup', { title: 'Create account' }))

// Profile & Dashboard
router.get('/profile', (req, res) => {
  res.render('profile', { title: 'Profile', user: req.user || null })
})

router.get('/dashboard', (req, res) => {
  res.render('dashboard', { title: 'Dashboard', user: req.user || null })
})

export default router